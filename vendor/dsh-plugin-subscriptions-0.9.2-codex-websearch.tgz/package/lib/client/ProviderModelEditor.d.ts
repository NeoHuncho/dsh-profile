import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { SubscriptionProvider } from './SubscriptionsSection.js';
import type { SubscriptionsKey } from './locales.js';
interface Props {
    provider: SubscriptionProvider;
    rpc: ConnectionHandle['rpc'];
    t: (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
}
/** Local draft: refreshes and failed saves never silently replace unsaved edits. */
export declare function ProviderModelEditor({ provider, rpc, t }: Props): import("react").JSX.Element;
export {};
